package com.example.simonsaysproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Controller extends AppCompatActivity implements SensorEventListener {
    public int Score;

    TextView tvx, tvy, tvz;
    private Button blue, red, yellow, green;
    private SensorManager mSensorManager;
    private Sensor mSensor;
    public int seqLength;
    public int[] Sequence;
    public int[] PlaySequence;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.controller);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        blue = findViewById(R.id.btnBlue);
        red = findViewById(R.id.btnRed);
        yellow = findViewById(R.id.btnYellow);
        green = findViewById(R.id.btnGreen);

        tvx = findViewById(R.id.tvX);
        tvy = findViewById(R.id.tvY);
        tvz = findViewById(R.id.tvZ);

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        Sequence = getIntent().getIntArrayExtra("Sequence");
        seqLength = Sequence.length;
        PlaySequence = new int [seqLength];
    }

    protected void onResume() {
        super.onResume();
        // turn on the sensor
        mSensorManager.registerListener(this, mSensor,
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);    // turn off listener to save power
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        tvx.setText(String.valueOf(x));
        tvy.setText(String.valueOf(y));
        tvz.setText(String.valueOf(z));
        }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // not used
    }



    public void RegisterChoice(View view) {

        double X = Double.parseDouble(tvx.getText().toString());
        double Y = Double.parseDouble(tvy.getText().toString());

        for (int i = 0; i < Sequence.length; i++) {

            if (X >= 5) {
                red.setBackgroundColor(Color.RED);
                PlaySequence[i] = 1;
                if (Sequence[i] == PlaySequence[i]) {
                    Toast.makeText(this, "Correct", Toast.LENGTH_LONG).show();
                    Score = Score + 1;
                    Intent intent = new Intent(getApplicationContext(), ScoreScreen.class);
                    intent.putExtra("score", Score);
                    intent.putExtra("Sequence", Sequence);
                    startActivity(intent);
                }
              else {
                        Toast.makeText(this, "Wrong", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(), ScoreScreen.class);
                        intent.putExtra( "score", Score );
                        intent.putExtra("Sequence", Sequence);
                        startActivity(intent);
                    }

            } else if (X <= -5) {

                blue.setBackgroundColor(Color.BLUE);
                PlaySequence[i] = 0;
                if (Sequence[i] == PlaySequence[i]) {
                    Toast.makeText(this, "Correct", Toast.LENGTH_LONG).show();
                    Score = Score + 1;
                    Intent intent = new Intent(getApplicationContext(), ScoreScreen.class);
                    intent.putExtra( "score", Score );
                    intent.putExtra("Sequence", Sequence);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(this, "Wrong", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), ScoreScreen.class);
                    intent.putExtra( "score", Score );
                    intent.putExtra("Sequence", Sequence);
                    startActivity(intent);
                }

            } else if (Y >= 5) {
                green.setBackgroundColor(Color.GREEN);
                PlaySequence[i] = 3;
                if (Sequence[i] == PlaySequence[i]) {
                    Toast.makeText(this, "Correct", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), ScoreScreen.class);
                    intent.putExtra( "score", Score );
                    intent.putExtra("Sequence", Sequence);
                    startActivity(intent);
                    Score = Score + 1;
                } else {
                    Toast.makeText(this, "Wrong", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), ScoreScreen.class);
                    intent.putExtra( "score", Score );
                    intent.putExtra("Sequence", Sequence);
                    startActivity(intent);
                }

            } else if (Y <= -5) {
                yellow.setBackgroundColor(Color.YELLOW);
                PlaySequence[i] = 2;
                if (Sequence[i] == PlaySequence[i]) {
                    Toast.makeText(this, "Correct", Toast.LENGTH_LONG).show();
                    Score = Score + 1;
                    Intent intent = new Intent(getApplicationContext(), ScoreScreen.class);
                    intent.putExtra( "score", Score );
                    intent.putExtra("Sequence", Sequence);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Wrong", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), ScoreScreen.class);
                    intent.putExtra( "score", Score );
                    intent.putExtra("Sequence", Sequence);
                    startActivity(intent);
                }
            }
        }
    }
}
