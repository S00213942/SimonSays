package com.example.simonsaysproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ScoreScreen extends AppCompatActivity {

    public int Score;

    public int[] Sequence;
    TextView scoreText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scorescreen);

        Score = getIntent().getIntExtra( "score", Score );
        Sequence = getIntent().getIntArrayExtra("Sequence");
        scoreText = findViewById(R.id.Score);

        String scoreStr = Integer.toString(Score);
        scoreText.setText(scoreStr);
    }

    public void keepPlaying(View view) {
        Intent intent=new Intent(this, Home.class);
        intent.putExtra( "score", Score );
        intent.putExtra( "Sequence", Sequence );
        startActivity(intent);
    }

}